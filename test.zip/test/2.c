int main() {
    /*
    this is an error test
    */ 
    int 0a;
    int bbc = 25;
    for (int a = 3; a < 5; a++) {
        bbc = bbc / 5;
    }
}