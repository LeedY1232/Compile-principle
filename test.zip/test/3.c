void main() {
    if (1 || 0) {
        int t = 0;
        int p;
        while (t < 3) {
            p = p + t ^ 2;
        }
    }
    // test 3
}